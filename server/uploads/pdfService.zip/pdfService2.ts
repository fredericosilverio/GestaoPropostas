import puppeteer from 'puppeteer';
import { PrismaClient } from '@prisma/client';
import { MarketAnalysisService } from './marketAnalysisService';
import path from 'path';
import fs from 'fs';

const prisma = new PrismaClient();
const marketAnalysisService = new MarketAnalysisService();

interface PdfServiceOptions {
    logoPath?: string;
    orgaoNome?: string;
}

export class PdfService {
    private options: PdfServiceOptions;

    constructor(options: PdfServiceOptions = {}) {
        this.options = {
            logoPath: options.logoPath || '',
            orgaoNome: options.orgaoNome || 'Estado de Goiás'
        };
    }

    async generateMarketAnalysisReport(demandaId: number): Promise<Buffer> {
        const demanda = await prisma.demanda.findUnique({
            where: { id: demandaId },
            include: {
                responsavel: { select: { nome_completo: true, email: true } },
                pca: true,
                itens: {
                    include: {
                        precos: {
                            where: { ativo: true },
                            orderBy: { valor_unitario: 'asc' }
                        }
                    },
                    orderBy: { codigo_item: 'asc' }
                }
            }
        });

        if (!demanda) {
            throw new Error('Demanda não encontrada');
        }

        const itensComEstatisticas = demanda.itens.map(item => {
            const stats = marketAnalysisService.calculateStatistics(item.precos);
            return { ...item, estatisticas: stats };
        });

        let logoBase64 = '';
        const logoPath = path.resolve(__dirname, '../../uploads', 'logo-tjgo.png');
        if (fs.existsSync(logoPath)) {
            const logoBuffer = fs.readFileSync(logoPath);
            logoBase64 = `data:image/png;base64,${logoBuffer.toString('base64')}`;
        }

        const html = this.generateHtml(demanda, itensComEstatisticas, logoBase64);

        const browser = await puppeteer.launch({
            headless: true,
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });

        const page = await browser.newPage();
        await page.setContent(html, { waitUntil: 'networkidle0' });

        const pdf = await page.pdf({
            format: 'A4',
            margin: { top: '0mm', bottom: '0mm', left: '0mm', right: '0mm' }, // Margens controladas pelo CSS da capa
            printBackground: true,
            displayHeaderFooter: true,
            headerTemplate: '<div></div>',
            footerTemplate: `
                <div style="width: 100%; font-size: 9px; text-align: center; color: #666; padding: 10px 0;">
                    <span>Relatório de Análise de Mercado - ${demanda.codigo_demanda}</span>
                    <span style="margin-left: 20px;">Página <span class="pageNumber"></span> de <span class="totalPages"></span></span>
                </div>
            `
        });

        await browser.close();
        return Buffer.from(pdf);
    }

    private generateHtml(demanda: any, itensComEstatisticas: any[], logoBase64: string): string {
        const dataEmissao = new Date().toLocaleDateString('pt-BR');
        const valorTotal = itensComEstatisticas.reduce(
            (acc, item) => acc + Number(item.valor_estimado_total || 0), 0
        );

        return `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <style>
        /* ========== RESET & BASE ========== */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            font-family: Arial, sans-serif;
            font-size: 11pt;
            color: #1a1a1a;
        }
        
        /* ========== CAPA OTIMIZADA ========== */
        .cover {
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: space-between; /* Distribui topo, centro e rodapé */
            align-items: center;
            text-align: center;
            padding: 60px 50px;
            page-break-after: always;
            border-top: 15px solid #1e3a5f;
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
        }
        
        .cover-header img {
            width: 90px;
            height: auto;
            margin-bottom: 10pt;
        }

        .cover-header h1 {
            font-size: 15pt;
            font-weight: bold;
            text-transform: uppercase;
            color: #000;
            margin-bottom: 4pt;
        }

        .cover-header .subtitle {
            font-size: 9.5pt;
            color: #333;
            margin-bottom: 2px;
        }

        /* Miolo da Capa */
        .cover-body {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            width: 100%;
        }
        
        .cover-body .doc-title {
            font-size: 26pt;
            font-weight: bold;
            color: #1e3a5f;
            margin-bottom: 40px;
            padding-bottom: 15px;
            border-bottom: 3px solid #c5a935;
            display: inline-block;
            align-self: center;
        }
        
        .cover-body .demanda-box {
            background: #f8f9fa;
            padding: 30px;
            max-width: 90%;
            margin: 0 auto;
            border-radius: 4px;
        }
        
        .cover-body .demanda-box h3 {
            font-size: 16pt;
            margin-bottom: 12px;
            color: #1a1a1a;
        }
        
        .cover-body .demanda-box p {
            font-size: 11.5pt;
            font-style: italic;
            color: #444;
            line-height: 1.5;
        }
        
        /* Rodapé da Capa */
        .cover-footer {
            width: 100%;
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            padding-top: 30px;
            border-top: 1px solid #ddd;
        }
        
        .cover-footer div { text-align: center; }
        .cover-footer strong { 
            display: block; 
            color: #1e3a5f; 
            font-size: 9pt; 
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        .cover-footer span { font-size: 10pt; color: #333; }
        
        /* ========== CONTEÚDO (PÁGINAS SEGUINTES) ========== */
        .content { 
            padding: 80px 50px 50px 50px; /* Espaço para o header do puppeteer */
        }
        
        .section-title {
            font-size: 13pt;
            font-weight: bold;
            color: #1e3a5f;
            margin: 25pt 0 12pt 0;
            padding-bottom: 4pt;
            border-bottom: 2px solid #1e3a5f;
            text-transform: uppercase;
        }

        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15pt;
            font-size: 10pt;
        }
        
        .info-table td {
            padding: 6pt;
            border: 1px solid #ddd;
        }
        
        .info-table .label {
            background: #f4f4f4;
            font-weight: bold;
            width: 20%;
        }

        .price-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 9pt;
            margin: 10pt 0;
        }
        
        .price-table th {
            background: #1e3a5f;
            color: white;
            padding: 5pt;
            text-align: left;
            text-transform: uppercase;
            font-size: 8pt;
        }

        .price-table td {
            padding: 4pt 5pt;
            border: 1px solid #eee;
        }

        .stats-line {
            display: flex;
            justify-content: space-between;
            background: #f0f4f8;
            padding: 8pt;
            border: 1px solid #d1d9e0;
            margin-top: -1px;
        }

        .stat-value { font-weight: bold; color: #1e3a5f; font-size: 10pt; }
        .stat-label { font-size: 7.5pt; color: #666; text-transform: uppercase; }

        .signature-section {
            margin-top: 50pt;
            display: flex;
            justify-content: space-around;
        }

        .signature-block {
            text-align: center;
            width: 200px;
            border-top: 1px solid #000;
            padding-top: 5pt;
        }
    </style>
</head>
<body>
    <div class="cover">
        <div class="cover-header">
            ${logoBase64 ? `<img src="${logoBase64}" alt="Logo">` : ''}
            <h1>Tribunal de Justiça do Estado de Goiás</h1>
            <p class="subtitle">Secretaria de Governança Judiciária e Tecnológica</p>
            <p class="subtitle">Diretoria de Infraestrutura em Tecnologia da Informação</p>
            <p class="subtitle">Coordenação de Contratos e Aquisições em TIC</p>
        </div>

        <div class="cover-body">
            <div class="doc-title">Relatório de Análise de Mercado</div>
            <div class="demanda-box">
                <h3>${demanda.codigo_demanda}</h3>
                <p>${demanda.descricao}</p>
            </div>
        </div>

        <div class="cover-footer">
            <div>
                <strong>PCA</strong>
                <span>${demanda.pca.ano} - v${demanda.pca.versao}</span>
            </div>
            <div>
                <strong>Unidade Demandante</strong>
                <span>${demanda.unidade_demandante || 'CSTI'}</span>
            </div>
            <div>
                <strong>Emissão</strong>
                <span>${dataEmissao}</span>
            </div>
        </div>
    </div>
    
    <div class="content">
        <div class="section">
            <h3 class="section-title">1. Identificação da Demanda</h3>
            <table class="info-table">
                <tr>
                    <td class="label">Código</td>
                    <td>${demanda.codigo_demanda}</td>
                    <td class="label">PCA</td>
                    <td>${demanda.pca.ano} - v${demanda.pca.versao}</td>
                </tr>
                <tr>
                    <td class="label">Unidade</td>
                    <td colspan="3">${demanda.unidade_demandante || 'CSTI'}</td>
                </tr>
            </table>
        </div>

        <div class="section">
            <h3 class="section-title">2. Análise de Preços</h3>
            ${itensComEstatisticas.map(item => `
                <div style="margin-bottom: 25pt; page-break-inside: avoid;">
                    <div style="font-weight: bold; color: #1e3a5f; margin-bottom: 5pt;">
                        Item ${item.codigo_item}: ${item.descricao}
                    </div>
                    <table class="price-table">
                        <thead>
                            <tr>
                                <th>Fonte</th>
                                <th>Data</th>
                                <th style="text-align: right;">Valor Unitário</th>
                                <th style="text-align: center;">Situação</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${item.precos.map((p: any) => `
                                <tr>
                                    <td>${p.fonte}</td>
                                    <td>${new Date(p.data_coleta).toLocaleDateString('pt-BR')}</td>
                                    <td style="text-align: right;">R$ ${Number(p.valor_unitario).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                                    <td style="text-align: center;">${p.classificacao}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    <div class="stats-line">
                        <div><span class="stat-label">Mediana:</span> <span class="stat-value">R$ ${Number(item.estatisticas.mediana || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span></div>
                        <div><span class="stat-label">Total Estimado:</span> <span class="stat-value">R$ ${Number(item.valor_estimado_total || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span></div>
                    </div>
                </div>
            `).join('')}
        </div>

        <div class="signature-section">
            <div class="signature-block">
                <p style="font-size: 10pt; font-weight: bold;">${demanda.responsavel?.nome_completo || 'Responsável'}</p>
                <p style="font-size: 8pt; color: #666;">Responsável pela Análise</p>
            </div>
            <div class="signature-block">
                <p style="font-size: 10pt; font-weight: bold;">Gestor da Unidade</p>
                <p style="font-size: 8pt; color: #666;">Aprovação</p>
            </div>
        </div>
    </div>
</body>
</html>`;
    }
}