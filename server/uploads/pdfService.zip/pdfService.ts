import puppeteer from 'puppeteer';
import { PrismaClient } from '@prisma/client';
import { MarketAnalysisService } from './marketAnalysisService';
import path from 'path';
import fs from 'fs';

const prisma = new PrismaClient();
const marketAnalysisService = new MarketAnalysisService();

interface PdfServiceOptions {
    logoPath?: string;
    orgaoNome?: string;
}

export class PdfService {
    private options: PdfServiceOptions;

    constructor(options: PdfServiceOptions = {}) {
        this.options = {
            logoPath: options.logoPath || '',
            orgaoNome: options.orgaoNome || 'Estado de Goiás'
        };
    }

    async generateMarketAnalysisReport(demandaId: number): Promise<Buffer> {
        // Fetch Demanda with all relations
        const demanda = await prisma.demanda.findUnique({
            where: { id: demandaId },
            include: {
                responsavel: { select: { nome_completo: true, email: true } },
                pca: true,
                itens: {
                    include: {
                        precos: {
                            where: { ativo: true },
                            orderBy: { valor_unitario: 'asc' }
                        }
                    },
                    orderBy: { codigo_item: 'asc' }
                }
            }
        });

        if (!demanda) {
            throw new Error('Demanda não encontrada');
        }

        // Calculate statistics for each item
        const itensComEstatisticas = demanda.itens.map(item => {
            const stats = marketAnalysisService.calculateStatistics(item.precos);
            return { ...item, estatisticas: stats };
        });

        // Generate HTML
        const html = this.generateHtml(demanda, itensComEstatisticas);

        // Launch puppeteer and generate PDF
        const browser = await puppeteer.launch({
            headless: true,
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });

        const page = await browser.newPage();
        await page.setContent(html, { waitUntil: 'networkidle0' });

        const pdf = await page.pdf({
            format: 'A4',
            margin: { top: '20mm', bottom: '25mm', left: '15mm', right: '15mm' },
            printBackground: true,
            displayHeaderFooter: true,
            headerTemplate: '<div></div>',
            footerTemplate: `
                <div style="width: 100%; font-size: 9px; text-align: center; color: #666; padding: 5px;">
                    <span>Relatório de Análise de Mercado - ${demanda.codigo_demanda}</span>
                    <span style="margin-left: 20px;">Página <span class="pageNumber"></span> de <span class="totalPages"></span></span>
                </div>
            `
        });

        await browser.close();

        return Buffer.from(pdf);
    }

    private generateHtml(demanda: any, itensComEstatisticas: any[]): string {
        const dataEmissao = new Date().toLocaleDateString('pt-BR');
        const valorTotal = itensComEstatisticas.reduce(
            (acc, item) => acc + Number(item.valor_estimado_total || 0), 0
        );

        return `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Relatório de Análise de Mercado</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 11px;
            line-height: 1.5;
            color: #333;
        }
        
        /* CAPA ESTILO */
        .cover {
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            page-break-after: always;
            background: #fff;
            padding: 40px;
            position: relative;
        }
        
        /* Barra superior decorativa */
        .cover::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 15px;
            background: #1e3a5f;
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
        }
        
        .header-logo {
            margin-top: 40px;
            margin-bottom: 20px;
            font-size: 48px;
            color: #1e3a5f;
        }

        .cover h1 {
            font-family: 'Times New Roman', serif;
            font-size: 22px;
            text-transform: uppercase;
            font-weight: bold;
            margin-bottom: 5px;
            color: #000;
        }
        
        .cover h2.subtitle {
            font-family: 'Segoe UI', sans-serif;
            font-size: 12px;
            font-weight: normal;
            color: #555;
            margin-bottom: 2px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .cover h2.doc-title {
            font-family: 'Segoe UI', sans-serif;
            font-size: 36px;
            font-weight: 700;
            color: #1e3a5f;
            margin: 80px 0 50px 0;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
        }
        
        .cover h2.doc-title::after {
            content: '';
            display: block;
            width: 100px;
            height: 4px;
            background: #c5a935; /* Gold accent */
            margin: 20px auto 0;
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
        }
        
        .cover .demanda-info {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            padding: 30px;
            border-radius: 8px;
            margin: 20px 0;
            width: 80%;
        }
        
        .cover .demanda-info h3 {
            font-size: 20px;
            margin-bottom: 10px;
            color: #333;
        }
        
        .cover .demanda-info p {
            font-size: 16px;
            color: #555;
            font-style: italic;
        }
        
        .cover .meta-info {
            margin-top: auto; /* Push to bottom */
            margin-bottom: 60px;
            border-top: 1px solid #ddd;
            padding-top: 20px;
            width: 100%;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            font-size: 11px;
            color: #666;
        }

        .cover .meta-info div {
            text-align: center;
        }

        .cover .meta-info strong {
            display: block;
            color: #333;
            margin-bottom: 3px;
        }
        
        /* RESTO DO CONTEÚDO */
        .content {
            padding: 40px;
        }
        
        .section {
            margin-bottom: 30px;
        }
        
        .section-title {
            font-size: 14px;
            font-weight: 700;
            color: #1e3a5f;
            border-bottom: 2px solid #1e3a5f;
            padding-bottom: 8px;
            margin-bottom: 20px;
            text-transform: uppercase;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .info-item {
            background: #fdfdfd;
            border: 1px solid #eaeaea;
            padding: 12px;
            border-radius: 4px;
        }
        
        .info-item label {
            font-size: 9px;
            color: #777;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: block;
            margin-bottom: 4px;
        }
        
        .info-item span {
            font-size: 12px;
            font-weight: 500;
            color: #333;
        }
        
        .methodology {
            background: #f0f7ff;
            padding: 20px;
            border-radius: 6px;
            border-left: 5px solid #1e3a5f;
            font-size: 11px;
            text-align: justify;
        }
        
        .methodology p {
            margin-bottom: 12px;
        }
        .methodology p:last-child {
            margin-bottom: 0;
        }
        
        .item-section {
            page-break-inside: avoid;
            margin-bottom: 30px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            overflow: hidden;
        }
        
        .item-header {
            background: #1e3a5f;
            color: white;
            padding: 12px 20px;
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
        }
        
        .item-header h4 {
            font-size: 13px;
            font-weight: 600;
        }
        
        .item-body {
            padding: 20px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            font-size: 10px;
        }
        
        th, td {
            border: 1px solid #e0e0e0;
            padding: 10px;
            text-align: left;
        }
        
        th {
            background: #f8f9fa;
            font-weight: 700;
            color: #495057;
            text-transform: uppercase;
            font-size: 9px;
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
        }
        
        .price-aceito { background: #e6ffec !important; print-color-adjust: exact; -webkit-print-color-adjust: exact; }
        .price-acima { background: #ffe6e6 !important; print-color-adjust: exact; -webkit-print-color-adjust: exact; }
        .price-abaixo { background: #fffbe6 !important; print-color-adjust: exact; -webkit-print-color-adjust: exact; }
        
        .stats-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
            margin-top: 15px;
            border: 1px solid #e9ecef;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-item .value {
            font-size: 15px;
            font-weight: 700;
            color: #1e3a5f;
        }
        
        .stat-item .label {
            font-size: 9px;
            color: #666;
            text-transform: uppercase;
            margin-top: 2px;
        }
        
        .estimated-value {
            background: #1e3a5f;
            color: white;
            padding: 15px 20px;
            border-radius: 6px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
        }
        
        .summary-box {
            background: #fff;
            color: #333;
            border: 2px solid #1e3a5f;
            padding: 25px;
            border-radius: 8px;
            text-align: center;
        }
        
        .summary-box h3 {
            font-size: 16px;
            margin-bottom: 10px;
            text-transform: uppercase;
            color: #1e3a5f;
        }
        
        .summary-box .total {
            font-size: 32px;
            font-weight: 700;
            color: #1e3a5f;
        }
        
        .currency {
            font-family: 'Consolas', monospace;
        }
    </style>
</head>
<body>
    <!-- CAPA -->
    <div class="cover">
        <div class="header-logo">
            ⚖️
        </div>
        <h1>Tribunal de Justiça do Estado de Goiás</h1>
        <h2 class="subtitle">Diretoria de Infraestrutura em Tecnologia da Informação</h2>
        <h2 class="subtitle">Coordenação de Contratos e Aquisições em TIC</h2>
        
        <h2 class="doc-title">Relatório de Análise de Mercado</h2>
        
        <div class="demanda-info">
            <h3>${demanda.codigo_demanda}</h3>
            <p>${demanda.descricao}</p>
        </div>
        
        <div class="meta-info">
            <div>
                <strong>PCA</strong>
                <span>${demanda.pca.ano} - Versão ${demanda.pca.versao}</span>
            </div>
            <div>
                <strong>UNIDADE</strong>
                <span>${demanda.unidade_demandante || 'Não informada'}</span>
            </div>
            <div>
                <strong>EMISSÃO</strong>
                <span>${dataEmissao}</span>
            </div>
        </div>
    </div>
    
    <!-- CONTEÚDO -->
    <div class="content">
        <!-- INFORMAÇÕES DA DEMANDA -->
        <div class="section">
            <h3 class="section-title">1. Identificação da Demanda</h3>
            <div class="info-grid">
                <div class="info-item">
                    <label>Código da Demanda</label>
                    <span>${demanda.codigo_demanda}</span>
                </div>
                <div class="info-item">
                    <label>PCA</label>
                    <span>${demanda.pca.numero_pca}/${demanda.pca.ano}</span>
                </div>
                <div class="info-item">
                    <label>Tipo de Contratação</label>
                    <span>${demanda.tipo_contratacao || 'Não informado'}</span>
                </div>
                <div class="info-item">
                    <label>Natureza da Despesa</label>
                    <span>${demanda.natureza_despesa || 'Não informado'}</span>
                </div>
                <div class="info-item">
                    <label>Elemento de Despesa</label>
                    <span>${demanda.elemento_despesa || 'Não informado'}</span>
                </div>
                <div class="info-item">
                    <label>Unidade Demandante</label>
                    <span>${demanda.unidade_demandante || 'Não informado'}</span>
                </div>
            </div>
            
            <div class="info-item" style="margin-top: 10px; text-align: justify;">
                <label>Justificativa Técnica</label>
                <span>${demanda.justificativa_tecnica || 'Não informada'}</span>
            </div>
        </div>
        
        <!-- METODOLOGIA -->
        <div class="section">
            <h3 class="section-title">2. Metodologia</h3>
            <div class="methodology">
                <p><strong>Base Legal:</strong> Este Relatório de Análise de Mercado foi elaborado em conformidade com a <strong>Lei Federal nº 14.133/2021</strong>, especialmente no que dispõe sobre o planejamento das contratações e a pesquisa de preços, bem como com o <strong>Decreto Estadual nº 9.900/2021</strong>, que regulamenta os procedimentos para pesquisa de preços no âmbito das contratações públicas do Estado de Goiás.</p>
                <p><strong>Critério de Aceitação dos Preços:</strong> Serão considerados válidos os preços que se encontrem dentro do intervalo de ±25% (vinte e cinco por cento) em relação à mediana dos valores coletados, conforme metodologia prevista na regulamentação vigente, com o objetivo de excluir valores excessivamente discrepantes e garantir maior aderência ao mercado.</p>
                <p><strong>Valor de Referência:</strong> O valor estimado da contratação foi definido com base na mediana dos preços válidos, adotada como critério principal por reduzir a influência de valores extremos (outliers) e proporcionar maior confiabilidade e representatividade do preço de mercado.</p>
                <p><strong>Fontes de Pesquisa:</strong> A pesquisa de preços foi realizada a partir de fontes diversificadas e idôneas, incluindo cotações obtidas junto a fornecedores, Painel de Preços do Governo Federal (ComprasNet, PNCP), bancos de preços estaduais e municipais, Atas de Registro de Preços vigentes e notas fiscais de contratações similares, de modo a assegurar a ampla representatividade e a fidedignidade dos valores coletados.</p>
            </div>
        </div>
        
        <!-- ITENS E PREÇOS -->
        <div class="section">
            <h3 class="section-title">3. Análise de Preços por Item</h3>
            
            ${itensComEstatisticas.map((item, index) => `
                <div class="item-section">
                    <div class="item-header">
                        <h4>Item ${item.codigo_item}: ${item.descricao}</h4>
                    </div>
                    <div class="item-body">
                        <div class="info-grid">
                            <div class="info-item">
                                <label>Unidade de Medida</label>
                                <span>${item.unidade_medida}</span>
                            </div>
                            <div class="info-item">
                                <label>Quantidade</label>
                                <span>${Number(item.quantidade).toLocaleString('pt-BR')}</span>
                            </div>
                        </div>
                        
                        ${item.especificacoes_tecnicas ? `
                            <div class="info-item" style="margin-bottom: 10px;">
                                <label>Especificações Técnicas</label>
                                <span>${item.especificacoes_tecnicas}</span>
                            </div>
                        ` : ''}
                        
                        <table>
                            <thead>
                                <tr>
                                    <th>Fonte</th>
                                    <th>Tipo</th>
                                    <th>Data Coleta</th>
                                    <th>Valor Unitário</th>
                                    <th>Classificação</th>
                                    <th>Variação</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${item.precos.map((preco: any) => `
                                    <tr class="${preco.classificacao === 'ACEITO' ? 'price-aceito' : preco.classificacao === 'ACIMA_DO_LIMITE' ? 'price-acima' : 'price-abaixo'}">
                                        <td>${preco.fonte}</td>
                                        <td>${preco.tipo_fonte}</td>
                                        <td>${new Date(preco.data_coleta).toLocaleDateString('pt-BR')}</td>
                                        <td class="currency">${Number(preco.valor_unitario).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
                                        <td>${preco.classificacao}</td>
                                        <td>${preco.percentual_variacao ? preco.percentual_variacao.toFixed(1) + '%' : '-'}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                        
                        <div class="stats-box">
                            <div class="stats-grid">
                                <div class="stat-item">
                                    <div class="value">${Number(item.estatisticas.media || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</div>
                                    <div class="label">Média</div>
                                </div>
                                <div class="stat-item">
                                    <div class="value">${Number(item.estatisticas.mediana || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</div>
                                    <div class="label">Mediana</div>
                                </div>
                                <div class="stat-item">
                                    <div class="value">${Number(item.estatisticas.desvioPadrao || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</div>
                                    <div class="label">Desvio Padrão</div>
                                </div>
                                <div class="stat-item">
                                    <div class="value">${(item.estatisticas.cv || 0).toFixed(1)}%</div>
                                    <div class="label">Coef. Variação</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="estimated-value">
                            <div>
                                <strong>Valor Estimado Unitário (Mediana):</strong>
                                <span class="currency" style="margin-left: 10px;">${Number(item.valor_estimado_unitario || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                            </div>
                            <div>
                                <strong>Valor Estimado Total:</strong>
                                <span class="currency" style="margin-left: 10px;">${Number(item.valor_estimado_total || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                            </div>
                        </div>
                    </div>
                </div>
            `).join('')}
        </div>
        
        <!-- RESUMO -->
        <div class="section">
            <h3 class="section-title">4. Resumo Consolidado</h3>
            <div class="summary-box">
                <h3>Valor Total Estimado da Demanda</h3>
                <div class="total currency">${valorTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</div>
                <p style="margin-top: 10px; font-size: 11px; opacity: 0.8;">
                    ${itensComEstatisticas.length} item(s) analisado(s) | ${itensComEstatisticas.reduce((acc, i) => acc + i.precos.length, 0)} preço(s) coletado(s)
                </p>
            </div>
        </div>
        
        <!-- ASSINATURA -->
        <div class="section" style="margin-top: 40px;">
            <div style="display: flex; justify-content: space-around; text-align: center;">
                <div>
                    <div style="border-top: 1px solid #333; width: 200px; padding-top: 5px;">
                        <p style="font-size: 10px;">${demanda.responsavel?.nome_completo || 'Responsável'}</p>
                        <p style="font-size: 9px; color: #666;">Responsável pela Análise</p>
                    </div>
                </div>
                <div>
                    <div style="border-top: 1px solid #333; width: 200px; padding-top: 5px;">
                        <p style="font-size: 10px;">Gestor</p>
                        <p style="font-size: 9px; color: #666;">Aprovação Técnica</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
        `;
    }
}
